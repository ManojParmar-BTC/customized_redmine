class PullRequest < ActiveRecord::Base
  unloadable
end
